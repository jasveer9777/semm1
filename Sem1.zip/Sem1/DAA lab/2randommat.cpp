#include<cstdlib>
#include<iostream>
#include<fstream>

using namespace std;
int main(){
	int n;
	cout<<"enter no of matrices"<<endl;
	cin>>n;
	srand(time(0));
	//cout<<time(0)<<" "<<endl;
	ofstream filee;
	filee.open("randmatr.csv");
	while(n--){
	int arr[2];
		for(int i=0;i<2;i++){
			arr[i]=(rand()%6)+(5)	;
			cout<<arr[i]<<" ";
			filee<<arr[i]<<",";
			
			}
			filee<<endl;
		int p=arr[0],k=arr[1];
		int mat[p][k];
		cout<<endl;
		for(int i=0;i<p;i++){
			for(int j=0;j<k;j++)
				{
					mat[i][j]=(rand()%91)+(10);
				}
		
		}
		for(int i=0;i<p;i++){
			for(int j=0;j<k;j++)
				{
					
					cout<<mat[i][j]<<" ";
					filee<<mat[i][j]<<",";
				}
				cout<<endl;
				filee<<endl;
		
		}
	}

return 0;
}
