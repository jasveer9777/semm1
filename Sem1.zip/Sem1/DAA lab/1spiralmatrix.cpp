#include <iostream>
using namespace std;

#define MAX_COLS 100

void printSpiral(int matrix[][MAX_COLS], int rows, int cols, int ans[], int &index) {
    int left = 0, right = cols - 1;
    int top = 0, bottom = rows - 1;
    
    while (left <= right && top <= bottom) {
        // left to right
        for (int i = left; i <= right; i++) {
            ans[index++] = matrix[top][i];
        }
        top++;
        
        // top to bottom
        for (int i = top; i <= bottom; i++) {
            ans[index++] = matrix[i][right];
        }
        right--;
        
        // right to left
        if (top <= bottom) {
            for (int i = right; i >= left; i--) {
                ans[index++] = matrix[bottom][i];
            }
            bottom--;
        }
        
        // bottom to top
        if (left <= right) {
            for (int i = bottom; i >= top; i--) {
                ans[index++] = matrix[i][left];
            }
            left++;
        }
    }
}

void recursiveSpiral(int matrix[][MAX_COLS], int top, int bottom, int left, int right, int ans[], int &index) {
    if (top > bottom || left > right) return;
    
    // left to right
    for (int i = left; i <= right; i++) {
        ans[index++] = matrix[top][i];
    }
    top++;
    
    // top to bottom
    for (int i = top; i <= bottom; i++) {
        ans[index++] = matrix[i][right];
    }
    right--;
    
    // right to left
    if (top <= bottom) {
        for (int i = right; i >= left; i--) {
            ans[index++] = matrix[bottom][i];
        }
        bottom--;
    }
    
    // bottom to top
    if (left <= right) {
        for (int i = bottom; i >= top; i--) {
            ans[index++] = matrix[i][left];
        }
        left++;
    }
    
    recursiveSpiral(matrix, top, bottom, left, right, ans, index);
}

int main() {
    int rows, cols;
    cout << "Enter rows and cols" << endl;
    cin >> rows >> cols;

    int matrix[rows][MAX_COLS]; 
    int ans[rows * cols];
    int index = 0;

    // Input matrix values
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            cin >> matrix[i][j];
        }
    }

    index = 0;
    printSpiral(matrix, rows, cols, ans, index);
    
    // Print the result of the iterative function
    cout << "Iterative Spiral Order:" << endl;
    for (int i = 0; i < index; i++) {
        cout << ans[i] << " ";
    }
    cout << endl;

    
    index = 0;
    recursiveSpiral(matrix, 0, rows - 1, 0, cols - 1, ans, index);

    
    cout << "Recursive Spiral Order:" << endl;
    for (int i = 0; i < index; i++) {
        cout << ans[i] << " ";
    }
    cout << endl;

    return 0;
}

