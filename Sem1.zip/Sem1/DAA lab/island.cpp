#include<iostream>

using namespace std;

void gridisland(){
	

}

int main(){
	
return 0;
}

